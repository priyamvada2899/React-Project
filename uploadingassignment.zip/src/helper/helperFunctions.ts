import { FileUploadType } from "../types/Status";

export const fileUploadFunc = (
  file: File,
  onProgress: (progress: number) => void,
  cancelSignal?: { cancelled: boolean }
): Promise<void> => {
  return new Promise<void>((resolve, reject) => {
    let progress = 0;

    const interval = setInterval(() => {
      if (cancelSignal?.cancelled) {
        clearInterval(interval);
        reject(new Error("Cancelled")); 
        return;
      }

      progress += Math.random() * 20;
      progress = Math.min(progress, 100);

      onProgress(Math.floor(progress));

      if (progress >= 100) {
        clearInterval(interval);

        const shouldFail = Math.random() < 0.1;

        setTimeout(() => {
          if (shouldFail) {
            reject(new Error("Network Error"));
          } else {
            resolve();
          }
        }, 500);
      }
    }, 300);
  });
};


export const createBalancedBatches = (
  files: FileUploadType[],
  numberOfBatches: number
) => {
  const sorted = [...files].sort(
    (a, b) => b.file.size - a.file.size
  );

  const batches: FileUploadType[][] = Array.from(
    { length: numberOfBatches },
    () => []
  );

  const batchSizes = new Array(numberOfBatches).fill(0);

  for (const file of sorted) {
    const smallestBatchIndex = batchSizes.indexOf(
      Math.min(...batchSizes)
    );

    batches[smallestBatchIndex].push(file);
    batchSizes[smallestBatchIndex] += file.file.size;
  }

  return batches;
};

