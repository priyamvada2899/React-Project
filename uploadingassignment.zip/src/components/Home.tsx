import React, { useCallback, useState } from 'react'
import { FileUploadType } from '../types/Status';
import { createBalancedBatches, fileUploadFunc } from '../helper/helperFunctions';
import toast from "react-hot-toast";
export const Home = () => {

    const [files, setFiles] = useState<FileUploadType[]>([]);

    const processFiles = (fileList: FileList) => {
        const selected: FileUploadType[] = Array.from(fileList).map((file: File) => ({
            id: crypto.randomUUID(),
            file,
            status: "selected",
            progress: 0,
            preview: file.type.startsWith("image/") ? URL.createObjectURL(file) : null,
        }));

        setFiles((prev) => [...prev, ...selected]);
        console.log("files:::",files)
        const numberOfBatches = Math.ceil(selected.length / 3);
        const batches = createBalancedBatches(selected, numberOfBatches);
        console.log("numberOfBatches",numberOfBatches);
        console.log("batches",batches);
        
        batches.forEach((batch) => {
            batch.forEach((file) => uploadFile(file));
        });

    };

    const handleFileSel = (e: React.ChangeEvent<HTMLInputElement>) => {
        const fileList = e.currentTarget.files;
        if (!fileList) return;
        processFiles(fileList);
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();

        if (e.dataTransfer.files) {
            processFiles(e.dataTransfer.files);
        }
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
    };

  

    const uploadFile = useCallback(async (item: FileUploadType) => {
        const cancelSignal = { cancelled: false };

        setFiles(prev =>
            prev.map(f =>
                f.id === item.id ? { ...f, status: "uploading", cancelSignal } : f
            )
        );

        try {
            await fileUploadFunc(item.file, (progress) => {
                setFiles(prev =>
                    prev.map(f =>
                        f.id === item.id ? { ...f, progress } : f
                    )
                );
            }, cancelSignal);

            setFiles(prev =>
                prev.map(f =>
                    f.id === item.id ? { ...f, status: "success", cancelSignal: undefined } : f
                )
            );
            toast.success(`${item.file.name} uploaded successfully!`);
        } catch (err: any) {
            if (err.message === "Cancelled") {
                setFiles(prev =>
                    prev.map(f =>
                        f.id === item.id ? { ...f, status: "cancelled", progress: 0, cancelSignal: undefined } : f
                    )
                );
                toast.error(`${item.file.name} upload cancelled`);
            } else {
                setFiles(prev =>
                    prev.map(f =>
                        f.id === item.id ? { ...f, status: "error", error: err.message, cancelSignal: undefined } : f
                    )
                );
                toast.error(`Failed to upload ${item.file.name} — ${err.message}`);
            }
        }
    }, []);



    const getFileCategory = (file: File) => {
        if (file.type.startsWith("image/")) return "image";
        if (file.type.startsWith("video/")) return "video";
        if (file.type === "application/pdf") return "pdf";
        if (
            file.type.includes("word") ||
            file.name.endsWith(".doc") ||
            file.name.endsWith(".docx")
        )
            return "doc";
        if (
            file.type.includes("sheet") ||
            file.name.endsWith(".xls") ||
            file.name.endsWith(".xlsx")
        )
            return "excel";

        return "other";
    };



    return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-white  bg-cover bg-center"
        >
            <div
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                className={`flex w-full transition-all
                ${files.length 
                ? "flex-col md:flex-row md:justify-start gap-6" 
                : "flex-col items-center justify-center"
               }`} >
               <div className="flex-col w-full md:w-1/2">
                    <div className='border shadow-lg py-6 px-10 rounded-lg bg-pink-100 '>
                        <h2 className="text-3xl font-semibold mb-8 text-pink-600 ">
                            Upload Your Files
                        </h2>

                        <input
                            type="file"
                            multiple
                            onChange={handleFileSel}
                            className="
                            mb-6
                            block w-full
                            text-sm text-gray-600
                            file:mr-4
                            file:py-2
                            file:px-6
                            file:rounded-full
                            file:border-0
                            file:text-sm
                            file:font-semibold
                            file:bg-pink-500
                            file:text-white
                            hover:file:bg-pink-600
                            file:transition
                            cursor-pointer"
                        />
                    </div>
                </div>

                <div className="w-full md:w-1/2 h-full overflow-y-auto p-6 space-y-4">
                    {files.map((item) => (
                        <div key={item.id} className="border p-4 rounded-lg shadow-sm bg-white">
                            <div className="flex items-center gap-3">
                                {getFileCategory(item.file) === "image" && item.preview ? (
                                    <img
                                        src={item.preview}
                                        alt="preview"
                                        className="w-12 h-12 object-cover rounded"
                                    />
                                ) : getFileCategory(item.file) === "pdf" ? (
                                    <span className="text-red-500 text-2xl">📄</span>
                                ) : getFileCategory(item.file) === "doc" ? (
                                    <span className="text-blue-500 text-2xl">📘</span>
                                ) : getFileCategory(item.file) === "excel" ? (
                                    <span className="text-green-600 text-2xl">📊</span>
                                ) : getFileCategory(item.file) === "video" ? (
                                    <span className="text-purple-500 text-2xl">🎥</span>
                                ) : (
                                    <span className="text-gray-500 text-2xl">📦</span>
                                )}
                            </div>

                            <div className="flex justify-between items-center mt-2">
                                <span className="font-medium">{item.file.name}</span>

                                {item.status === "success" && (
                                    <span className="text-green-600 text-sm">Success</span>
                                )}
                                {item.status === "error" && (
                                    <span className="text-red-600 text-sm">Failed</span>
                                )}
                                {item.status === "uploading" && (
                                    <span className="text-blue-600 text-sm">Uploading...</span>
                                )}
                                {item.status === "cancelled" && (
                                    <span className="text-orange-500 text-sm">Cancelled</span>
                                )}
                            </div>

                            {item.status === "uploading" && (
                                <div className="flex items-center mt-3 gap-4">

                                    <button
                                        onClick={() => {
                                            setFiles(prev =>
                                                prev.map(f => {
                                                    if (f.id === item.id) {
                                                        f.cancelSignal && (f.cancelSignal.cancelled = true); 
                                                        return { ...f };
                                                    }
                                                    return f;
                                                })
                                            );
                                        }}
                                        className="text-white bg-red-500 p-2 rounded-lg text-sm hover:underline"
                                    >
                                        Cancel
                                    </button>
                                    <div className="flex-1 bg-gray-200 h-2 rounded">
                                        <div
                                            className="bg-blue-600 h-2 rounded"
                                            style={{ width: `${item.progress}%` }}
                                        />
                                    </div>
                                </div>
                            )}

                            {item.status === "error" && (
                                <p className="text-sm text-red-500 mt-2">{item.error}</p>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}
