export type UploadStatus = "uploading" | "success" | "error" | "cancelled" | "selected";

export interface FileUploadType {
  id: string;
  file: File;
  progress: number;
  status: UploadStatus;
  error?: string;
  preview?: string | null;
  cancelIntervalId?: number;
  cancelSignal?: { cancelled: boolean };
}