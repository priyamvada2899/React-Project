import React from 'react';
import './App.css';
import {
  Routes,
  Route,
} from "react-router-dom";
import { Home } from './components/Home';
import { Toaster } from "react-hot-toast";

function App() {
  return (
    <div >
     <Routes>
          <Route path="/" element={<Home />} />
     </Routes>
      <Toaster position="top-right" />
    </div>
  );
}

export default App;
